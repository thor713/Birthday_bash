// ===============================
// PERSONALIZE YOUR WEBSITE HERE
// ===============================
const CONFIG = {
  recipient: "Someone Special",
  from: "Your Special Someone 💗",
  birthday: "2026-12-31T00:00:00"
};

// Optional: if you add music.mp3 beside index.html, set this to "music.mp3"
const MUSIC_FILE = "";

const screens = ["intro","countdown","memories","reveal","celebrate","party","cake","message","letter"];

function show(id){
  document.querySelectorAll(".screen").forEach(s => s.classList.remove("active"));
  document.getElementById(id).classList.add("active");
  window.scrollTo({top:0,behavior:"smooth"});
}

function startJourney(){
  document.getElementById("nameTop").textContent = CONFIG.recipient;
  document.getElementById("nameLetter").textContent = CONFIG.recipient;
  document.getElementById("fromName").textContent = CONFIG.from;
  show("countdown");
  updateTimer();
}

function updateTimer(){
  const target = new Date(CONFIG.birthday).getTime();
  const now = Date.now();
  let diff = Math.max(0,target-now);
  const d = Math.floor(diff/86400000); diff%=86400000;
  const h = Math.floor(diff/3600000); diff%=3600000;
  const m = Math.floor(diff/60000); diff%=60000;
  const s = Math.floor(diff/1000);
  document.getElementById("days").textContent = String(d).padStart(2,"0");
  document.getElementById("hours").textContent = String(h).padStart(2,"0");
  document.getElementById("minutes").textContent = String(m).padStart(2,"0");
  document.getElementById("seconds").textContent = String(s).padStart(2,"0");
}
setInterval(updateTimer,1000);

function turnLights(){
  document.body.classList.add("lights-on");
  show("party");
}

function playMusic(){
  const audio = document.getElementById("music");
  if(MUSIC_FILE){
    audio.src = MUSIC_FILE;
    audio.play().catch(()=>{});
  }else{
    // A tiny Web Audio chime so the button still feels interactive.
    try{
      const C = window.AudioContext || window.webkitAudioContext;
      const ctx = new C();
      [523.25,659.25,783.99].forEach((freq,i)=>{
        const osc=ctx.createOscillator(), gain=ctx.createGain();
        osc.frequency.value=freq; osc.type="sine";
        gain.gain.setValueAtTime(0,ctx.currentTime+i*.12);
        gain.gain.linearRampToValueAtTime(.08,ctx.currentTime+i*.12+.02);
        gain.gain.exponentialRampToValueAtTime(.001,ctx.currentTime+i*.12+.45);
        osc.connect(gain); gain.connect(ctx.destination);
        osc.start(ctx.currentTime+i*.12); osc.stop(ctx.currentTime+i*.12+.5);
      });
    }catch(e){}
  }
}
document.querySelector("#party .party-btn").addEventListener("click",()=>{playMusic();show("cake")});

function blowCandles(){
  document.querySelectorAll(".flames span").forEach(x=>x.style.opacity="0");
  setTimeout(()=>show("message"),800);
}

function openLetter(){ show("letter"); }

function restart(){
  document.querySelectorAll(".flames span").forEach(x=>x.style.opacity="1");
  show("intro");
}

document.addEventListener("DOMContentLoaded",()=>{
  document.getElementById("nameTop").textContent=CONFIG.recipient;
  document.getElementById("nameLetter").textContent=CONFIG.recipient;
  document.getElementById("fromName").textContent=CONFIG.from;
});
