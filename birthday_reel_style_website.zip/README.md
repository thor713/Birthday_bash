# Birthday Surprise Website

This is a mobile-first birthday/surprise website inspired by the flow of the uploaded Instagram reel.

## Customize
Open `script.js` and change:

- `recipient` — person's name
- `from` — your name/signature
- `birthday` — target date/time

For music, put an MP3 named `music.mp3` in the same folder and change:
`const MUSIC_FILE = "music.mp3";`

## Run
Simply open `index.html` in a browser.

For a public link, upload the folder to GitHub Pages, Netlify, Vercel, or another static-hosting service.
